$(document).ready(function () {
  /* navbar toggler */

  $('.navbar-toggler').html("<i class='fa fa-arrow-down fa-3x' style='color:#f15025'></i>");

  // smooth scroll







});
